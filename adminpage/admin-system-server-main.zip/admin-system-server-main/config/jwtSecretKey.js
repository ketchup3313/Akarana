module.exports = {
    jwtSecretKey: 'akarana_club'
}