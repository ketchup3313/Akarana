import mitt from 'mitt';
//订阅发布监听切换重新请求接口
const emitter = mitt();

export default emitter;