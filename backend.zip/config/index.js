module.exports = {
  jwtKey: 'YYS',
}
